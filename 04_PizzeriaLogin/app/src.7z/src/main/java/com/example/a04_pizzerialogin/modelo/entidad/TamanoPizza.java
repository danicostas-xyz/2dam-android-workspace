package com.example.a04_pizzerialogin.modelo.entidad;

public enum TamanoPizza {
    GRANDE, MEDIANA, PEQUENA, UNDEFINED
}
